#!/bin/bash
id > /app/extracted/_output.txt
cat /etc/passwd >> /app/extracted/_output.txt
