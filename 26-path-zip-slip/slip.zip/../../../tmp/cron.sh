#!/bin/bash
cat /flag.txt
id
ls -la /tmp /app
